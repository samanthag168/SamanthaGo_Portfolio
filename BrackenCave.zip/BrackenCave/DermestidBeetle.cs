﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrackenCave
{
    internal class DermestidBeetle : Decomposers
    {
        public string name = "Dermestid Beetle";
        public string Species = "Dermestes carnivora";
    }
}
