﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrackenCave
{
     class Hawk : Consumers
    {
        public string name = "Red-tailed hawk";
        public string Species = "Buteo jamaicensis";
    }
}
