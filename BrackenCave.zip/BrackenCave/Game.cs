﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace BrackenCave
{
    internal class Game
    {
        #region SetUp
        public Environment environment = new Environment();
        Weather weather = new Weather();
        public int numDays;
        Player player = new Player()
        {
            Currency = 50,
            Inventory =
            {
            new Item() {Name = "Guano", Amount = 0, Price = 10},
            new Item() {Name = "Cotton", Amount = 0, Price = 8 },
            new Item() { Name = "Corn", Amount = 0, Price = 7},
            new Item() { Name = "Owl Decoy", Amount = 0}

            }
        };
        Vendor vendor = new Vendor()
        {
            Inventory =
            {
            new Item() {Name = "Guano", Amount = 3, Price = 15},
            new Item() {Name = "Cotton", Amount = 4, Price = 10 },
            new Item() { Name = "Corn", Amount = 3, Price = 10},
            new Item() { Name = "Owl Decoy", Amount = 1, Price = 7}

            }
        };

        public string ShowPlayerCurrency() => $"{player.Currency.ToString("c")}";
        public string ShowPlayerInventory()
        {
            string output = "";
            foreach (Item i in player.Inventory)
            {
                output += $"{i.Amount} {i.Name}\n";
            }
            return output;
        }
        public void SetUp()
        {
            environment.entities = Utility.LoadEntities("../../../AmountProperty.xml");
            
            numDays = 1;
            weather.GetWeather();
        }
        public string ShowWeather()
        {
            string output = weather.GetWeather();
            return output;

        }
        public void Tonextday()
        {
            weather.GetWeather();
            CheckEntityAmount();
        }
        #endregion
        //public string RainyDayConditions()
        //{
        //    string output = "";
        //    return output;
        //}
       
        public void Buy(string name)
        {
            foreach (Item i in vendor.Inventory)
            {
                if (i.Name == name && player.Currency >= i.Price)
                {
                    player.Additem(i.Name, i.Amount);
                    player.Currency -= i.Price;
                }

            }
        }
        public void Sell(string name)
        {
            foreach (Item i in player.Inventory)
            {
                if (i.Name == name && i.Amount > 0)
                {
                    i.Amount -= 1;
                    player.Currency += i.Price;
                }
            }
        }
        public void CheckEntityAmount()
        {
            if (numDays > 1)
            {
                int bats = environment.AmountOfEntityBySpecies("Tadarida brasiliensis");
                int worms = environment.AmountOfEntityBySpecies("Helicoverpa zea");
                int hawks = environment.AmountOfEntityBySpecies("Buteo jamaicensis"); 
                int beetles = environment.AmountOfEntityBySpecies("Dermestes carnivora");
                int crops = environment.AmountOfEntityBySpecies("Zea mays saccharata") + environment.AmountOfEntityBySpecies("Gossypium hirsutum");
               
                int batsfoodAmount = 100;
                int batFood = bats * batsfoodAmount;

                if (worms < batFood)
                {
                    //if the total amount of worms is less than the amount of bats multiplied by the amount of worms bats eat daily, bat population decreases
                    environment.ChangeAmountOfEntityBySpecies("Tadarida brasiliensis", -1);
                }
                else if (worms > batFood)
                {
                    environment.ChangeAmountOfEntityBySpecies("Tadarida brasiliensis", 1);
                }
                int wormsperCrops = 2;
                decimal wormcropsRatio = crops/wormsperCrops;
                if (worms > 1)
                {
                    if (worms < wormcropsRatio)
                    {
                        environment.ChangeAmountOfEntityBySpecies("Helicoverpa zea", -10);
                    }
                    else
                    {
                        environment.ChangeAmountOfEntityBySpecies("Helicoverpa zea", 5);
                    }
                         
                }
                Random rand = new Random(); 
                if (hawks > 1)
                { 
               int hawkeats = rand.Next(1,2);
                    if (beetles > 1)
                    {
                        if (hawkeats == 2)
                        {
                            environment.ChangeAmountOfEntityBySpecies("Dermestes carnivora", -1);
                        }
                        else if (player.Inventory[3].Amount > 0)
                        {
                            environment.ChangeAmountOfEntityBySpecies("Dermestes carnivora", 2);
                        }
                    }
                    
                }
              

            }
        
        }
           
    }
}
