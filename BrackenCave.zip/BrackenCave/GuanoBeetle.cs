﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrackenCave
{
     class GuanoBeetle : Decomposers, IGuano
    {
        public string name = "Guano Beetle";
        public string Species = "Jacobsoniidae";
        int IGuano.ProduceGuano()
        {
            return (Amount) + 1;
        }
    }
}
