﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrackenCave
{
    public class Cotton
    {
        public string name = "Cotton";
        public string Species = "Gossypium hirsutum";
    }
}
