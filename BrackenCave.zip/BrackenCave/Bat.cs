﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrackenCave
{
    class Bat : Consumers, IGuano
    {
        public string name = "Bat";
        public static new string Species = "Tadarida brasiliensis";
        int IGuano.ProduceGuano()
        {
            return (Amount) + 1;
        }
    }
}
