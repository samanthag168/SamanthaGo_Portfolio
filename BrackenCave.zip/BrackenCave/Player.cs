﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrackenCave
{
    class Player : Entity
    {
        public string Species = "human";
        public List<Item> Inventory = new List<Item>();
        public double Currency { get; set; }
        public void Additem(string Name, double Amount)
        {
            foreach (Item i in Inventory)
            {
                if (i.Name.ToLower() == Name.ToLower())
                {
                    i.Amount += Amount;
                }
            }
        }
        public void RemoveItem(double amount)
        {

            foreach (Item i in Inventory)
            {
                if (i.Amount > 0)
                {
                    i.Amount -= 1;
                }
                else if (i.Name == Name)
                {
                    i.Amount = 0;
                }
            }
        }
        public void DecreaseAmount(string Name, int amount)
        {
            foreach (Item i in Inventory)
            {
                if (i.Name == Name)
                {
                    i.Amount -= amount;
                }
            }
        }
        public void IncreaseAmount(string Name, int amount)
        {
            foreach (Item i in Inventory)
            {
                if (i.Name == Name)
                {
                    i.Amount += amount;
                }
            }
        }
    }
}
