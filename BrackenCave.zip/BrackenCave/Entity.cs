﻿using BrackenCave;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace BrackenCave
{
    public class Entity
    {
        //Code is from PROG 2 demos
        private string name;
        private string species;
        private int amount;

        public string Status = "";
        public string Name { get => name; set => name = value; }
        public string Species { get => species; set => species = value; }
        //public Entitystatus entitystatus;
        //enum Entitystatus
        //{ 
        //stable,
        //endangered,
        //unsound
        //}
        public int Amount
        {

            get => amount;

            set
            {
                if (amount == value) return;
                if (value < 0) { amount = 0; return; }
                decimal oldAmount = amount;
                amount = value;
                OnAmountChanged(new AmountChangedEventArgs(oldAmount, amount));
            }
        }

        public event EventHandler<AmountChangedEventArgs> AmountChanged;

        protected virtual void OnAmountChanged(AmountChangedEventArgs e)
        {
            AmountChanged?.Invoke(this, e);
        }

        public void Entity_AmountChanged(object sender, AmountChangedEventArgs e)
        {
            if (e.LastAmount > e.NewAmount)
            {

                if (Species == "Tadarida brasiliensis")
                {
                    Status = "ALERT: Bat population is decreasing";

                }
                else if (Species == "Helicoverpa zea")
                {
                    Status = "ALERT: Corn earworm population is decreasing";

                }
                else if (Species == "Zea mays saccharata" || Species == "Gossypium hirsutum")
                {
                    Status = "ALERT: The amount of crops is decreasing";
                }
                else if (Species == "Dermestes carnivora")
                {
                    Status = "ALERT: Beetle population is decreasing";

                }

            }
        }

        public class AmountChangedEventArgs : EventArgs
        {
            public readonly decimal LastAmount;
            public readonly decimal NewAmount;

            public AmountChangedEventArgs(decimal lastAmount, decimal newAmount)
            {
                LastAmount = lastAmount; NewAmount = newAmount;
            }
        }

    }
   
    
}
public class Vendor : Entity
{
    public string Species = "human";
    public List<Item> Inventory = new List<Item>();
}
public class Decomposers : Entity
{

}
public class Consumers : Entity
{

}
public class Producers : Entity
{

}
