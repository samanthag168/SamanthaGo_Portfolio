﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrackenCave
{
    public class Corn : Producers
    {
        public string name = "Corn";
        public string Species = "Zea mays saccharata";
    }
}
