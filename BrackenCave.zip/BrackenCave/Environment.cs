﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace BrackenCave
{
    public class Environment
    {
        private string name = "Bracken Cave Ecosystem";
        Player player = new Player();
       public string Name { get => name; set => name = value; }
       public List<Entity> entities = new List<Entity>();
        #region weather
        Weather weather = new Weather();
        //Event Handler weather changes
        //public event EventHandler<EventArgs> WeatherChanged;
        //protected virtual void OnWeatherChanged(EventArgs e)
        //{
        //    WeatherChanged?.Invoke(this, e);
        //}
        //public void Weather_WeatherEffects(object sender,e)
        //{
        //    if (weather.weatherConditions == weatherConditions.rainy)
        //    {
        //        player.DecreaseAmount("Cotton", 2);
        //        ChangeAmountOfEntityBySpecies("Gossypium hirsutum", -2);

        //    }
        //    else if (weather.weatherConditions == weatherConditions.sunny)
        //    {
        //        player.IncreaseAmount("Corn", 1);
        //        player.IncreaseAmount("Cotton", 1);
        //        ChangeAmountOfEntityBySpecies("Zea mays saccharata", 1);
        //        ChangeAmountOfEntityBySpecies("Gossypium hirsutum", 1);
        //    }
        //    else if (weather.weatherConditions == weatherConditions.cold)
        //    {
        //        player.DecreaseAmount("Corn", 3);
        //        ChangeAmountOfEntityBySpecies("Zea mays saccharata", -3);
        //    }
        //}
        //public class WeatherEffectsEventArgs : EventArgs
        //{ 

        //}
        public void WeatherEffects()
        {
            if (weather.weatherConditions == weatherConditions.rainy)
            {
                player.DecreaseAmount("Cotton", 2);
                ChangeAmountOfEntityBySpecies("Gossypium hirsutum", -2);

            }
            else if (weather.weatherConditions == weatherConditions.sunny)
            {
                player.IncreaseAmount("Corn", 1);
                player.IncreaseAmount("Cotton", 1);
                ChangeAmountOfEntityBySpecies("Zea mays saccharata", 1);
                ChangeAmountOfEntityBySpecies("Gossypium hirsutum", 1);
            }
            else if (weather.weatherConditions == weatherConditions.cold)
            {
                player.DecreaseAmount("Corn", 3);
                ChangeAmountOfEntityBySpecies("Zea mays saccharata", -3);
            }
        }
        #endregion 

        public int AmountOfEntityBySpecies(string species)
        {
            int output = 0;
            foreach (Entity e in entities)
            {
                if (e.Species.ToLower() == species.ToLower())
                {
                    output += e.Amount;
                }
            }

            return output;
        }
        public void ChangeAmountOfEntityBySpecies(string species, int amount)
        {
            foreach (Entity e in entities)
            {
                if (e.Species.ToLower() == species.ToLower())
                {
                    e.Amount += amount;
                }
            }
            
        }

    }
}
