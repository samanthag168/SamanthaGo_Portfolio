﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrackenCave
{
    class Worm : Consumers
    {
        public string name = "Corn Earworm";
        public string Species = "Helicoverpa zea";
    }
   
}
