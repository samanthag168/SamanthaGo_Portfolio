﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrackenCave
{
    //weather classs was created with the help of tutor Ciarenn Hollis
    public class Weather
    {
        public int temperature;
        public int minTemp = 5;
        public int maxTemp = 104;
        public string weatherReport;
        public weatherConditions weatherConditions; 
        Random random = new Random();

        public string GetWeather()
        {
            temperature = random.Next(minTemp, maxTemp);
            int tempnum;
            if (temperature < 30)
            {
                weatherConditions = weatherConditions.cold;
            }
            if (temperature > 30)
            {
                weatherConditions = weatherConditions.rainy;
            }
            if (temperature > 87)
            {
                weatherConditions = weatherConditions.sunny;
            }
            //tempnum = random.Next(0,2);
            //weatherConditions = (weatherConditions)tempnum;
            weatherReport = $"Temperature = {temperature}\nWeather conditions = {weatherConditions.ToString()}";
            return weatherReport;
        }
        
        
    }
    public enum weatherConditions
    {
        rainy,
        sunny,
        cold
    }
}
