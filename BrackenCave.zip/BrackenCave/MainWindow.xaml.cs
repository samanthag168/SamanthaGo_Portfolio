﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BrackenCave
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Environment environment = new Environment();
        Weather weather = new Weather();

        Game game = new Game();
        public MainWindow()
        {
            InitializeComponent();
            game.SetUp();
          
            EnvironmentName.DataContext = game.environment;
            CurrencyTextblock.Text = game.ShowPlayerCurrency();
            PlayerInventory.Text = game.ShowPlayerInventory();
            DayTextblock.Text = "Day " + game.numDays.ToString();
            WeatherConditionsTextblock.Text = game.ShowWeather();
            //AlertTextblock.Text = game.environment.entities.Count.ToString();
        }
        public delegate void PrintPlayerInfo(string message);
        public static PrintPlayerInfo print = PrintWPF;
        public static void PrintWPF(string message)
        {
            message = "Player Info: ";
            
        }

        private void BuyGuanoButton_Click(object sender, RoutedEventArgs e)
        {
            //Guano helps grow more crops 
            game.Buy("Guano");
            
            RefreshInformation();
        }
        private void RefreshInformation()
        {
            CurrencyTextblock.Text = game.ShowPlayerCurrency();
            PlayerInventory.Text = game.ShowPlayerInventory();
            
        }

        private void BuyCottonButton_Click(object sender, RoutedEventArgs e)
        {
            //increase of cotton bollworm population decreases cotton population
            game.Buy("Cotton");
            game.environment.ChangeAmountOfEntityBySpecies("Gossypium hirsutum", 1);
            RefreshInformation();
        }

        private void BuyCornButton_Click(object sender, RoutedEventArgs e)
        {
            //corn earworm moth makes corn population decrease, bats eat corn earworm moths 
            game.Buy("Corn");
            game.environment.ChangeAmountOfEntityBySpecies("Zea mays saccharata", 1);
            RefreshInformation();
        }

        private void SellGuanoButton_Click(object sender, RoutedEventArgs e)
        {
            game.Sell("Guano");
            RefreshInformation();
        }

        private void SellCottonButton_Click(object sender, RoutedEventArgs e)
        {
            game.Sell("Cotton");
            game.environment.ChangeAmountOfEntityBySpecies("Gossypium hirsutum", -1);
            RefreshInformation();
        }

        private void SellCornButton_Click(object sender, RoutedEventArgs e)
        {
            game.Sell("Corn");
            game.environment.ChangeAmountOfEntityBySpecies("Zea mays saccharata", -1);
            RefreshInformation();
        }
        private void UpdateNextday()
        {
            DayTextblock.Text = "Day " + game.numDays.ToString();
            WeatherConditionsTextblock.Text = game.ShowWeather();
            CropsTextblock.Text = "";
            
        }
        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            game.numDays++;
            game.Tonextday();
            game.environment.WeatherEffects();
            UpdateNextday();
            UpdateEnvironmentInformation();

            if (weather.weatherConditions == weatherConditions.rainy)
            {
                CropsTextblock.Text = "The rainy weather has ruined the quality of your cotton. You have lost 2 cotton crops";
               

            }
            if (weather.weatherConditions == weatherConditions.sunny)
            {
                CropsTextblock.Text = "It's sunny, you have gained one cotton and one corn crop";
               

            }
             if (weather.weatherConditions == weatherConditions.cold)
            {
                CropsTextblock.Text = "The cold weather has damaged your corn crops, you lost 3 corn crops";
                

            }
           
            RefreshInformation();
            
           
            
        }
        //the code below is from a prog 2 demo
        private void UpdateEnvironmentInformation()
        {
            // .....
            foreach (Entity e in game.environment.entities)
            {

                //only update player about the entities that aren't the player and vendor
                if (e.Species.ToLower() != "human")
                    UpdatePlayerOnRatios(e);
            }

        }

        private void UpdatePlayerOnRatios(Entity entity)
        {
            entity.AmountChanged += entity.Entity_AmountChanged;

            if (entity.Status != "")
            {
                string current = AlertTextblock.Text;
                AlertTextblock.Text = $"Day {game.numDays}: {entity.Status}\n" + current;
            }
        }

        private void BuyOwlDecoyButton_Click(object sender, RoutedEventArgs e)
        {
            game.Buy("Owl Decoy");
            RefreshInformation();
        }
    }
}
