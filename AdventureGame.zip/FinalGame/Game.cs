﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalGame
{
    public class Game
    {
        //Game is about the player's missing friend, the player goes to locations that you and the friend have gone to multiple times
        //you collect items and clues that leads you to find the missing person in the woods, the items are the friend's possessions
        public string Title { get; set; }
        public List<Locations> Locations = new List<Locations>();
        public Locations CurrentLocation { get; set; }
        public Player CurrentPlayer = new Player();

        public Game()
        {
            Item Sunglasses = new Item()
            {
                ItemName = "Heart Sunglasses",
            };
            Item Candy = new Item()
            {
                ItemName = "Strawberry candy",
            };
            Item Fungi = new Item()
            {
                ItemName = "Fungi",
            };
            Item FairyWing = new Item()
            {
                ItemName = "Fairy wings",

            };
            Item BlackCandle = new Item()
            {
                ItemName = "Black Candle",

            };
            RequiredItem Ramune = new RequiredItem()
            {
                NeededName = "Ramune drink",

            };
            Item Money = new Item()
            {
                ItemName = "$24",

            };
            Item SpecialGift = new Item()
            {
                ItemName = "Special Gift",

            };
            Item Letter = new Item()
            {
                ItemName = "Thank you letter",

            };
            Item Jewelry = new Item()
            {
                ItemName = "Pearl Necklace",

            };
            Item Pearl = new Item()
            {
                ItemName = "Pearl"
            };

            NPCs Ghost = new NPCs()
            {
                NPCName = "Ghost",
                NPCDescription = "Cute ghost that likes making potions",
                ImagePath = "Media/Ghost.png",
                Item = SpecialGift, 
                DesiredItem = FairyWing,
                neededItem = Ramune
                //Also wants Fungi
            };
            NPCs Cashier = new NPCs()
            {
                NPCName = "Cashier",
                NPCDescription = "The only cashier at the convenience store",
                ImagePath = "Media/npc.png",
                Item = Ramune, 
                DesiredItem = Money
            };
            NPCs Fairy = new NPCs()
            {
                NPCName = "Faerie",
                NPCDescription = "Gentle fairy that likes using black candles",
                ImagePath = "Media/fairy.png",
                Item = FairyWing,
                DesiredItem = BlackCandle 
            };
            NPCs Sister = new NPCs()
            {
                NPCName = "Older sister",
                NPCDescription = "your rich older sister",
                ImagePath = "Media/npc2.png",
                Item = Money,
                DesiredItem = Sunglasses 
            };
            NPCs BeachWanderer = new NPCs()
            {
                NPCName = "Beach wanderer",
                NPCDescription = "A random stranger that lives on the beach",
                ImagePath = "Media/npc3.png",
                Item = Pearl,
                DesiredItem = Candy
            };
            NPCs BestFriend = new NPCs()
            {
                NPCName = "Beach wanderer",
                NPCDescription = "A random stranger that lives on the beach",
                ImagePath = "Media/friend.png",
                Item = Letter,
                DesiredItem = SpecialGift,
              
            };
            Animal Crab = new Animal()
            {
                AnimalName = "Surf Crab"
            };
            Animal Fox = new Animal()
            {
                AnimalName = "White Fox"
            };
            Locations Beach = new Locations()
            {
                LocationName = "Coral Beach",
                Description = "Quiet, relaxing beach in your hometown",
                ImagePath = "Media/Beaches.png",
                Item = Sunglasses,
                NPC = BeachWanderer,
                Animal = Crab 
                
            };
            Locations.Add(Beach); 
            Locations Graveyard = new Locations()
            {
                LocationName = "Graveyard",
                Description = "eerie and sinister graveyard where most of your hometown's urban legends occur",
                ImagePath = "Media/graveyard.png",
                Item = BlackCandle,
                NPC = Ghost
            };
            Locations.Add(Graveyard);
            Locations Store = new Locations()
            {
                LocationName = "Convenience store",
                Description = "Our favorite place to buy snacks",
                ImagePath = "Media/location1.png",
                Item = Candy,
                NPC = Cashier
            };
            Locations.Add(Store);
            Locations Forest = new Locations()
            {
                LocationName = "Elfin Forest",
                Description = "Rumored to be haunted. There have been sightings of staircases in the middle of the forest",
                ImagePath = "Media/forest.png",
                Item = Fungi,
                NPC = Fairy,
                Animal = Fox

            };
            Locations.Add(Forest);
            Locations ShoppingCenter = new Locations()
            {
                LocationName = "Pacific Shopping Center",
                Description = "The biggest shopping center in your hometown",
                ImagePath = "Media/street.png",
                Item = Jewelry,
                NPC = Sister
              
            };
            Locations.Add(ShoppingCenter);
        }
    }
}
