﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalGame
{
    public class Locations
    {
        public string LocationName { get; set; }

        public string Description { get; set; }

        public string ImagePath { get; set; }

        public Item Item { get; set; }

        public NPCs NPC { get; set; }
        public Animal Animal { get; set; }
    }

}
