﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinalGame
{
    /// <summary>
    /// Interaction logic for ShoppingCenter.xaml
    /// </summary>
    public partial class ShoppingCenter : Page
    {
        public ShoppingCenter()
        {
            InitializeComponent();
        }

        private void ItemButton_Click(object sender, RoutedEventArgs e)
        {
            var item = MainWindow.game.CurrentLocation.Item;
            MainWindow.game.CurrentPlayer.AddToInventory(item);
            MessageBox.Show($"{MainWindow.game.CurrentLocation.Item.ItemName} has been added to your inventory.");
            ItemButton.Opacity = 0.5;
        }

        private void NPCButton_Click(object sender, RoutedEventArgs e)
        {
            Uri OlderSisterNPC = new Uri("OlderSisterNPC.xaml", UriKind.Relative);
            NavigationService.Navigate(OlderSisterNPC);
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Uri Location = new Uri("Location.xaml", UriKind.Relative);
            NavigationService.Navigate(Location);
        }
    }
}
