﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinalGame
{
    /// <summary>
    /// Interaction logic for TitleScreen.xaml
    /// </summary>
    public partial class TitleScreen : Page
    {
        public TitleScreen()
        {
            InitializeComponent();
            //IntroTextbox.Text = $"Welcome {MainWindow.game.CurrentPlayer.PlayerName}, it's your best friends birthday and you must give them a special gift. In order to get your special gift you must explore a few areas and trade items with NPCs";
        }

        private void LocationsButton_Click(object sender, RoutedEventArgs e)
        {
            Uri Location = new Uri("Location.xaml", UriKind.Relative);
            NavigationService.Navigate(Location);
        }
    }
}