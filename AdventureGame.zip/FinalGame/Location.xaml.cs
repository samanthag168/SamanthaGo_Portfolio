﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinalGame
{
    /// <summary>
    /// Interaction logic for Location.xaml
    /// </summary>
    public partial class Location : Page
    {
        public Location()
        {
            InitializeComponent();
            PlayerNameLabel.Content = MainWindow.game.CurrentPlayer.PlayerName;
            ImageSourceConverter imageSourceConverter = new ImageSourceConverter();
            Uri imageUri = new Uri(MainWindow.game.CurrentPlayer.Avatar, UriKind.Relative);
            PlayerAvatarImage.Source = (ImageSource)imageSourceConverter.ConvertFrom(imageUri);


            foreach (var item in MainWindow.game.CurrentPlayer.Inventory)
            {
                InventoryTextbox.Text += $"{item}\n";
            }
        }

        

        private void Forest_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.game.CurrentLocation = MainWindow.game.Locations.FirstOrDefault(x => x.LocationName == "Elfin Forest");
            Uri Forest = new Uri("Forest.xaml", UriKind.Relative);
            NavigationService.Navigate(Forest);
        }

        private void Store_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.game.CurrentLocation = MainWindow.game.Locations.FirstOrDefault(x => x.LocationName == "Convenience store");
            Uri Store = new Uri("Store.xaml", UriKind.Relative);
            NavigationService.Navigate(Store);
        }

        private void Beach_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.game.CurrentLocation = MainWindow.game.Locations.FirstOrDefault(x => x.LocationName == "Coral Beach");
            Uri Beach = new Uri("Beach.xaml", UriKind.Relative);
            NavigationService.Navigate(Beach);
        }

        private void ShoppingCenter_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.game.CurrentLocation = MainWindow.game.Locations.FirstOrDefault(x => x.LocationName == "Pacific Shopping Center");
            Uri ShoppingCenter = new Uri("ShoppingCenter.xaml", UriKind.Relative);
            NavigationService.Navigate(ShoppingCenter);
        }

        private void Visit_Click(object sender, RoutedEventArgs e)
        {
            if (MainWindow.game.CurrentPlayer.Inventory.Contains("Special Gift") && MainWindow.game.CurrentPlayer.Inventory.Contains("Pearl") && MainWindow.game.CurrentPlayer.Inventory.Contains("Pearl Necklace"))
            {
                Uri VisitBF = new Uri("VisitBestFriend.xaml", UriKind.Relative);
                NavigationService.Navigate(VisitBF);
            }
            else
            {
                MessageBox.Show("You are missing the special gift, pearl, and pearl necklace");
            }

        }

        private void Graveyard_Click(object sender, RoutedEventArgs e)
        {

            MainWindow.game.CurrentLocation = MainWindow.game.Locations.FirstOrDefault(x => x.LocationName == "Graveyard");

            Uri Graveyard = new Uri("Graveyard.xaml", UriKind.Relative);
            NavigationService.Navigate(Graveyard);
        }

        private void RichTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
