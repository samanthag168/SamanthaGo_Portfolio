﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinalGame
{
    /// <summary>
    /// Interaction logic for CashierNPC.xaml
    /// </summary>
    public partial class CashierNPC : Page
    {
        public CashierNPC()
        {
            InitializeComponent();
        }

        private void backbutton_Click(object sender, RoutedEventArgs e)
        {
            Uri Store = new Uri("Store.xaml", UriKind.Relative);
            NavigationService.Navigate(Store);
        }

        private void TradeButton_Click(object sender, RoutedEventArgs e)
        {
            var desiredItem = MainWindow.game.CurrentLocation.NPC.DesiredItem;
            if (MainWindow.game.CurrentPlayer.Inventory.Contains(desiredItem.ItemName))
            {
                var item = MainWindow.game.CurrentLocation.NPC.Item;

                MainWindow.game.CurrentPlayer.AddToInventory(item);
                MainWindow.game.CurrentPlayer.Inventory.Remove(desiredItem.ItemName);
                MessageBox.Show($"{MainWindow.game.CurrentLocation.NPC.Item.ItemName} has been added to your inventory");
                TradeButton.Opacity = 0.5;
            }
            else
            {
                MessageBox.Show($"You will need {desiredItem.ItemName} in order to trade this item.");
            }

        }
    }
}
