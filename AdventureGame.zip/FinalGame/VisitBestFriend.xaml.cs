﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinalGame
{
    /// <summary>
    /// Interaction logic for VisitBestFriend.xaml
    /// </summary>
    public partial class VisitBestFriend : Page
    {
        public VisitBestFriend()
        {
            InitializeComponent();
        }

        private void GiveButton_Click(object sender, RoutedEventArgs e)
        {
            Uri End = new Uri("End.xaml", UriKind.Relative);
            NavigationService.Navigate(End);
        }
    }
}
