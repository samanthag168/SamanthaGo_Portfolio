﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalGame
{
    public class NPCs
    {
        public string NPCName { get; set; }
        public string NPCDescription { get; set; }
        public string ImagePath { get; set; }
        public Item Item { get; set; }

        public Item DesiredItem { get; set; }
        public RequiredItem neededItem { get; set; }
    }
}
