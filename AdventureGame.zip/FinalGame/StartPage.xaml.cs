﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinalGame
{
    /// <summary>
    /// Interaction logic for StartPage.xaml
    /// </summary>
    public partial class StartPage : Page
    {
        public StartPage()
        {
            InitializeComponent();
            //ImageSourceConverter imageSourceConverter = new ImageSourceConverter();
            //Uri imageUri = new Uri("avatar1.png", UriKind.Relative);
            //Avatar1.Source = (ImageSource)imageSourceConverter.ConvertFrom(imageUri);
            Avatar1.Tag = "media/avatar1.png";
            //Uri imageUri2 = new Uri("avatar2.png", UriKind.Relative);
            //Avatar2.Source = (ImageSource)imageSourceConverter.ConvertFrom(imageUri);
            Avatar2.Tag = "media/avatar2.png";

            //Uri imageUri3 = new Uri("avatar3.png", UriKind.Relative);
            Avatar3.Tag = "media/avatar3.png";
            //Avatar3.Source = (ImageSource)imageSourceConverter.ConvertFrom(imageUri);
           //Uri imageUri4 = new Uri("Avatar4.png", UriKind.Relative);
            //Avatar4.Source = (ImageSource)imageSourceConverter.ConvertFrom(imageUri);
            Avatar4.Tag = "media/Avatar4.png";
        }

        private void Avatar1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            
            Image avatarImage = (Image)sender;
            MainWindow.game.CurrentPlayer.Avatar = avatarImage.Tag.ToString();
            Avatar1.Opacity = 0.5;
            Avatar2.Opacity = 0.5;
            Avatar3.Opacity = 0.5;
            Avatar4.Opacity = 0.5;
            avatarImage.Opacity = 1; 
        }
        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrEmpty(MainWindow.game.CurrentPlayer.Avatar) && !String.IsNullOrEmpty(PlayerNameTextbox.Text))
            {

                MainWindow.game.CurrentPlayer.PlayerName = PlayerNameTextbox.Text;
                Uri Start = new Uri("TitleScreen.xaml", UriKind.Relative);
                NavigationService.Navigate(Start);
            }
            else
            {
                MessageBox.Show("Please enter a name for your character and select an avatar.");
            }
        }
    }
}
