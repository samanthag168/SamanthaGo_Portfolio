﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinalGame
{
    /// <summary>
    /// Interaction logic for Forest.xaml
    /// </summary>
    public partial class Forest : Page
    {
        public Forest()
        {
            InitializeComponent();
        }

        private void NPCButton_Click(object sender, RoutedEventArgs e)
        {
            Uri FairyNPC = new Uri("FairyNPC.xaml", UriKind.Relative);
            NavigationService.Navigate(FairyNPC);
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Uri Location = new Uri("Location.xaml", UriKind.Relative);
            NavigationService.Navigate(Location);
        }

        private void TradeButton_Click(object sender, RoutedEventArgs e)
        {
            var item = MainWindow.game.CurrentLocation.Item;
            MainWindow.game.CurrentPlayer.AddToInventory(item);
            MessageBox.Show($"{MainWindow.game.CurrentLocation.Item.ItemName} has been added to your inventory.");
            CollectButton.Opacity = 0.5; 
        }

        private void AnimalButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"You have befriended a {MainWindow.game.CurrentLocation.Animal.AnimalName}!");
            AnimalButton.Opacity = 0.5; 
        }
    }
}
