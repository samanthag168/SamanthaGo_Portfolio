﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalGame
{
    public class Player
    {
        public string PlayerName { get; set; }
        public List<string> Inventory = new List<string>();
        public string Avatar { get; set; }

        public List<string> TradeItems = new List<string>();
        
        public bool AddToInventory(Item item)
        {
            if (!Inventory.Contains(item.ItemName) && !TradeItems.Contains(item.ItemName))
            {
                
                //Trade can proceed
                Inventory.Add(item.ItemName);
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool CheckInventory(Item item)
        { 
            return Inventory.Contains(item.ItemName);
        }
    }
}
