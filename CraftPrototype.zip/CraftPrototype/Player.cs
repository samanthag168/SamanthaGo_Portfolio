﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CraftPrototype
{
    class Player : Person
    {
        //Code below was created with the help of tutor Karen Spriggs
        public void Additem(string Name, double Amount)
        {
            foreach (Item i in Inventory)
            {
                if (i.Name.ToLower() == Name.ToLower())
                { 
                i.Amount += Amount;
                }
            }
        }
        public void RemoveItem(string Name, double Amount)
        {

            foreach (Item i in Inventory)
            {
                if (i.Name == Name && i.Amount >= Amount)
                {
                    i.Amount -= Amount;
                }
                else if (i.Name == Name)
                {
                    i.Amount = 0;
                }
            }
        }
    }
}
