﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CraftPrototype
{
    class Person
    {
        public string Name { get; set; }
        public double Currency { get; set; }
        public List<Item> Inventory = new List<Item>();
    }
}
