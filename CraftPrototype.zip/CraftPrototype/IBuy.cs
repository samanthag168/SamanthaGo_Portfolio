﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CraftPrototype
{
    internal interface IBuyProduct 
    {
        public string BuyBakeryGoods()
        {
            string output = "A bakery item has been bought";
            return output;

        }
    }
}
