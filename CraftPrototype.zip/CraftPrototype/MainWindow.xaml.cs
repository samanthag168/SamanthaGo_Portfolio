﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static CraftPrototype.Game;

namespace CraftPrototype
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Game game = new Game();
        bool craft = true;
        bool buy = false;
        bool sell = false;
        //public delegate void DisplayPlayerCurrency();
        //public DisplayPlayerCurrency Display = DisplayCurrency;
        public MainWindow()
        {
            InitializeComponent();
            DisplayInventory();
            DisplayRecipes();
            RefreshInformation();
            DisplayCurrency();
        }

     
        private void DisplayRecipes()
        {
            PersonTextBlock.Text = "Welcome to Craft!";
            RecipesTextBlock.Text = game.ShowRecipes("../../../data/Recipes.txt") + "\n \nWhich recipe would you like to make? Please type a number for 1-5 that corresponds with the recipe on the list";
        }
        private void DisplayIngredients()
        {
            RecipesTextBlock.Text = game.ShowIngredients("../../../data/Buy.txt") + "\n \nWhich ingredients would you like to buy? Please type which ingredient you want";
        }
        //private void DisplayCraftedItems()
        //{
        //    InventoryTextBlock.Text = game.showCraftedItems();
        //}
        private void DisplayInventory()
        {
            
            InventoryTextBlock.Text = game.ShowPlayerInventory();
        }
       
        private void DisplayCurrency()
        {
            CurrencyText.Text = "Money: " + game.ShowPlayerCurrency();
        }
        private void RefreshInformation()
        { 
                CurrencyText.Text = "Money: " + game.ShowPlayerCurrency();
                DisplayInventory();

        }
        //private void RefreshCraftedItems()
        //{
        //    CurrencyText.Text = "Money: " + game.ShowPlayerCurrency();
        //    //DisplayCraftedItems();
        //}
        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (craft)
            {
               

                switch (InputBox.Text)
                {
                    case "1":
                        game.Craft(1); 
                        break;
                    case "2":
                        game.Craft(0);
                        break;
                    case "3":
                        game.Craft(2);
                        break;
                    case "4":
                        game.Craft(4);
                        break;
                    case "5":
                        game.Craft(3);
                        break;
                    default:
                        MessageBox.Show("Please type a valid response");
                        break;
                }
               
            }
            else if (buy)
            {
                PersonTextBlock.Text = game.ShowMerchantName();
                switch (InputBox.Text.ToLower())
                {
                    case "powdered sugar":
                        game.BuyIngredients("powdered sugar");
                        break;
                    case "bananas":
                        game.BuyIngredients("bananas");
                        break;
                    case "eggs":
                        game.BuyIngredients("eggs");
                        break;
                    case "cacao powder":
                        game.BuyIngredients("cacao powder");
                        break;
                    case "vanilla extract":
                        game.BuyIngredients("vanilla extract");
                        break;
                    case "milk":
                        game.BuyIngredients("milk");
                        break;
                    case "almond flour":
                        game.BuyIngredients("almond flour");
                        break;
                    case "sugar":
                        game.BuyIngredients("sugar");
                        break;
                    case "strawberries":
                        game.BuyIngredients("strawberries");
                        break;
                    case "semi sweet chocolate chips":
                        game.BuyIngredients("semi sweet chocolate chips");
                        break;
                    case "white chocolate chips":
                        game.BuyIngredients("white chocolate chips");
                        break;
                    case "condensed milk":
                        game.BuyIngredients("condensed milk");
                        break;
                    case "cocoa powder":
                        game.BuyIngredients("cocoa powder");
                        break;
                    default:
                        MessageBox.Show("Please type a valid answer");
                        break;
                }
               
            }
            else if (sell)
            {
                
                switch (InputBox.Text)
                {
                    case "chocolate cake":
                        game.Sell("chocolate cake");
                        
                        break;
                    case "french macaron":
                        game.Sell("french macaron");
                        break;
                    case "chocolate truffles":
                        game.Sell("chocolate truffles");
                        break;
                    case "chocolate covered strawberries":
                        game.Sell("chocolate covered strawberries");
                        break;
                    default:
                        MessageBox.Show("Please type a valid answer");
                        break;
                }
            }
            RefreshInformation();

        }

        private void BuyButton_Click(object sender, RoutedEventArgs e)
        {
            buy = true;
            craft = false;
            sell = false;
           RefreshInformation();
            DisplayIngredients();
            DisplayInventory();
            PersonTextBlock.Text = game.ShowMerchantName();
        }

        private void SellButton_Click(object sender, RoutedEventArgs e)
        {
            buy = false;
            craft = false;
            sell = true;
            PersonTextBlock.Text = game.ShowCustomerName();
            RecipesTextBlock.Text = game.ShowBakeryMenu();
            //DisplayCraftedItems();
        }

        private void CraftItemsButton_Click(object sender, RoutedEventArgs e)
        {
            
            craft = true;
            sell = false;
            buy = false;
            DisplayRecipes();
            RefreshInformation();
        }
    }
}
