﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CraftPrototype
{
    class Merchant : Person
    {
        public string Name { get; set; }
        public List<Item> Inventory = new List<Item>();
    }
}
