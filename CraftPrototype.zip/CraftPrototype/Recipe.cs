﻿using System;
using System.Collections.Generic;
using System.Security.Policy;
using System.Text;

namespace CraftPrototype
{
    class Recipe
    {
        //Macaron recipe from https://www.foodnetwork.com/recipes/macarons-recipe-1925577
        //chocolate strawberries https://www.foodnetwork.com/recipes/food-network-kitchen/chocolate-covered-strawberries-recipe-1941747
        //truffles https://www.youtube.com/watch?v=4_YBELE4LpM
        public string Name { get; set; }
        public List<Item> Requirements { get; set; }
        public int Amount { get; set; }
        public double Price { get; set; }
        
    }
}
