﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CraftPrototype
{
    class Item
    {
        
        public string Name;
        public double Amount;
        public double Price;
        public string Measurements;
        //profitValue code was created with the help of Tutor Ciarenn Hollis
        public double profitValue;
   
    }
}
