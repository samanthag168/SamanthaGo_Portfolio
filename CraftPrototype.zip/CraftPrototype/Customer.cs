﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CraftPrototype
{
     class Customer : Person, IBuyProduct
    {
        public string Name { get; set; }
        public List<Item> Inventory = new List<Item>(); 
        public delegate void PrintName(string message);
        public static PrintName Print = PrintCustomerName;

        public static string BuyBakeryGoods()
        {
            string output = "A bakery item has been bought";
            return output;
        }
        public static void PrintCustomerName(string name)
        {
            string output = $"{name}";
           
        }
    }
}
