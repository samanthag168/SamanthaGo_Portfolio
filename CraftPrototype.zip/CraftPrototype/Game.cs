﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Windows;

namespace CraftPrototype
{
    class Game
    {
        /* PROG 201 Craft Project
 * Your Name: Samantha Go
 * Date: 11/4/22
 * Credits: PROG 2 demos, Janell Baxter, and Tutor Karen Spriggs helped me program part of the code
 * */
        public enum Mode
        { 
        craft,
        buy,
        sell
        
        }
        public string gameMode;
        
        List<Recipe> Recipes = new List<Recipe>();
        //List<Item> Ingredients = new List<Item>()
        //{
        //   new Item() {Name = "powdered sugar", Amount = 3, Price = 2 },
        //   new Item() {Name = "bananas", Amount = 4, Price = 3.20},
        //   new Item() {Name = "eggs", Amount = 12, Price = 5.50 },
        //   new Item() {Name = "cacao powder", Amount = 6, Price = 3.99},
        //    new Item() {Name = "vanilla extract", Amount = 12, Price = 5.50 },
        //   new Item() {Name = "milk", Amount = 6, Price = 3.50},
        //    new Item() {Name = "almond flour", Amount = 6, Price = 3 },
        //   new Item() {Name = "sugar", Amount = 2, Price = 2.75},
        //   new Item() {Name = "strawberries", Amount = 2, Price = 3.20},
        //    new Item() {Name = "semi sweet chocolate chips", Amount = 6, Price = 2.50 },
        //   new Item() {Name = "white chocolate chips", Amount = 6, Price = 2.50},
        //    new Item() {Name = "condensed milk", Amount = 240, Price = 2 },
        //   new Item() {Name = "cocoa powder", Amount = 100, Price = 2.99},



        //};
        Player player = new Player() { Inventory = new List<Item>
        {
            new Item() { Name = "Milk", Amount = 2,  },
            new Item() { Name = "Vanilla Extract", Amount = 0.5, Measurements = "tsp" },
            new Item() { Name = "Powdered Sugar", Amount = 2, Measurements = "cup" },
            new Item() { Name = "Bananas", Amount = 2 },
            new Item() { Name = "Eggs", Amount = 2 },
            new Item() { Name = "Cacao Powder", Amount = 2, Measurements = "tbsp" },
            new Item() { Name = "Powdered Sugar Icing", Amount = 0, Measurements = "cup" },
            new Item() {Name = "Almound Flour", Amount = 0, Measurements = "cup"},
             new Item() {Name = "Sugar", Amount = 0, Measurements = "cup"},
              new Item() {Name = "Strawberries", Amount = 0, Measurements = "pound"},
             new Item() {Name = "Semi-sweet Chocolate Chips", Amount = 0, Measurements = "ounces"},
              new Item() {Name = "White Chocolate Chips", Amount = 0, Measurements = "ounces"},
              new Item() {Name = "Condensed Milk", Amount = 0, Measurements = "grams"},
             new Item() {Name = "Cocoa Powder", Amount = 0, Measurements = "grams"},

        }, Currency = 0
        };
        Merchant merchant = new Merchant() { Name = "Ingredients Supplier",Inventory = new List<Item>
        {
        new Item() {Name = "powdered sugar", Amount = 3, Price = 2 },
           new Item() {Name = "bananas", Amount = 4, Price = 3.20},
           new Item() {Name = "eggs", Amount = 12, Price = 5.50 },
           new Item() {Name = "cacao powder", Amount = 6, Price = 3.99},
            new Item() {Name = "vanilla extract", Amount = 12, Price = 5.50 },
           new Item() {Name = "milk", Amount = 6, Price = 3.50},
            new Item() {Name = "almond flour", Amount = 6, Price = 3 },
           new Item() {Name = "sugar", Amount = 2, Price = 2.75},
           new Item() {Name = "strawberries", Amount = 2, Price = 3.20},
            new Item() {Name = "semi sweet chocolate chips", Amount = 6, Price = 2.50 },
           new Item() {Name = "white chocolate chips", Amount = 6, Price = 2.50},
            new Item() {Name = "condensed milk", Amount = 240, Price = 2 },
           new Item() {Name = "cocoa powder", Amount = 100, Price = 2.99},

        }
            };
        //List<Item> craftedProducts = new List<Item>();
        Customer customer = new Customer() { Name = "Happy Customer"
        
        };

        public Game()
        {
            Recipes.Add(
                new Recipe()
                {
                    Name = "Powdered Sugar Icing",
                    Requirements = new List<Item>()
                    {
                    new Item(){ Name = "Milk",Amount = 2, Measurements = "tbsp", Price = 0.50},
                    new Item(){ Name = "Vanilla Extract",Amount = 0.5, Measurements = "tsp", Price = 0.50},
                    new Item(){ Name = "Powdered Sugar",Amount = 1, Measurements = "cup", Price = 0.70}
                    },
                    Amount = 1
              
                }
                );
            Recipes.Add(
               new Recipe()
               {
                   Name = "Chocolate Cake",
                   Requirements = new List<Item>()
                    {
                    new Item(){Name = "Powdered Sugar Icing", Amount = 1, Measurements = "cup", Price = 1.70 },
                    new Item(){ Name = "Bananas",Amount = 2, Price = 2},
                    new Item(){ Name = "Eggs",Amount = 2, Price = 1},
                    new Item(){ Name = "Cacao Powder",Amount = 2, Measurements = "tbsp", Price = 0.60}
                    },
                   Amount = 1,
                   Price = 32
               }
            ); ;
            Recipes.Add(
               new Recipe()
               {
                   Name = "French Macaron",
                   Requirements = new List<Item>()
                   {
                        new Item(){Name = "Almond Flour", Amount = 2, Measurements = "cup", Price = 2},
                       new Item(){Name = "Eggs", Amount = 3, Price = 1.50},
                         new Item(){Name = "Sugar", Amount = 0.25, Measurements = "cup", Price = 0.90 },
                        new Item(){Name = "Powdered Sugar", Amount = 1, Measurements = "cup", Price = 0.90 }
                   },
                   Amount = 11,
                   Price = 18

               }
               );
            Recipes.Add(
              new Recipe()
              {
                  Name = "Chocolate Truffles",
                  Requirements = new List<Item>()
                  {
                       new Item(){Name = "Condensed Milk", Amount = 240, Measurements = "grams", Price = 2 },
                        new Item(){Name = "Cocoa Powder", Amount = 100, Measurements = "grams", Price = 2.99 }
                  },
                  Amount = 20,
                  Price = 12

              }
              );
            Recipes.Add(
             new Recipe()
             {
                 Name = "Chocolate Covered Strawberries",
                 Requirements = new List<Item>()
                 {
                       new Item(){Name = "Semi-sweet Chocolate", Amount = 6, Measurements = "ounces", Price = 2.50 },
                        new Item(){Name = "White Chocolate", Amount = 3, Measurements = "ounces", Price = 1.25},
                        new Item(){Name = "Strawberries", Amount = 1, Measurements = "pound", Price = 1.10 }
                 },
                 Amount = 10,
                 Price = 20

             }
             );

        }
        public double DetermineProfit(Recipe recipe)
        {
            double cost = 0;
            foreach (Item i in recipe.Requirements)
            {
                cost += i.Price;
            }
            return recipe.Price - cost; 
        }
        //Showrecipes() and ShowPlayerInventory() code is from programming II craft demo 
        public string ShowRecipes(string filename)
        {
            string Content = "";
            if (File.Exists(filename))
            {
                Content = File.ReadAllText(filename);
            };
            return Content;
            //string output = "Recipes:\n";
            //foreach (Recipe r in Recipes)
            //{
            //    output += $"  * {r.ShowRecipeDetails()}\n";
            //}
            //return output;

        }
        public string ShowIngredients(string filename)
        {
            string Content = "";
            if (File.Exists(filename))
            {
                Content = File.ReadAllText(filename);
            };
            return Content;
        }
        //public string showCraftedItems()
        //{
        //    string output = "Crafted Items:\n";
        //    foreach (Item i in craftedProducts)
        //    {
        //        output += $"{i.Amount} {i.Name}\n";
        //    }
        //    return output;
        //}
        public string ShowPlayerInventory()
        {
            string output = "Current inventory:\n";
            foreach (Item i in player.Inventory)
            {
                output += $"  * {i.Name} ({i.Amount} {i.Measurements})\n";
            }
            return output;
        }
        public string ShowBakeryMenu()
        {
            string output = $"The {customer.Name} would like to buy every item you can make: \n";
            foreach (Recipe r in Recipes)
            {
                output += $"{r.Name}: {r.Price.ToString("c")} \n"; 
            }
            return output + "\n Please type the name of the item you want to sell"; ; 
        }
        //Code below was created with the help of tutor Karen Spriggs
        public bool Compare(List<Item> ingredients)
        {
            bool CanMake = true;

        foreach (Item i in ingredients)
            { 
            CanMake = ItemInList(i);
          
            }
        return CanMake;
        }
        public bool ItemInList(Item item)
        {
            foreach (Item i in player.Inventory)
            {
                if (i.Name == item.Name && i.Amount>= item.Amount)
                {
                    return true;
                }
            }
            return false; 
        }
        //Craft method was created with the help of Janell Baxter
        public void Craft(int num)
        {
            Mode gameMode = Mode.craft;
           
            if (Compare(Recipes[num].Requirements))
            {
                //profitValue code was created with the help of tutor Ciarenn Hollis
                player.Inventory.Add(new Item() { Name = Recipes[num].Name, Amount = Recipes[num].Amount, Price = Recipes[num].Price, profitValue = DetermineProfit(Recipes[num])});
               
               
                foreach (Item i in Recipes[num].Requirements)
                {
                    player.RemoveItem(i.Name, i.Amount);
                   
                }
            }
            else
            {
                MessageBox.Show("You do not have enough ingredients");
            }
        }
  
        public void BuyIngredients(string name)
        {
            Mode gameMode = Mode.buy;
            foreach (Item i in merchant.Inventory)
            {
                if (name.ToLower() == i.Name.ToLower())
                {

                    if (player.Currency >= i.Price)
                    {
                        player.Additem(i.Name, i.Amount);
                        player.Currency -= i.Price;
                        MessageBox.Show($"{i.Name} has been added to your inventory.");
                    }
                    else
                    {
                        MessageBox.Show("you dont have enough money");
                    }
                }
               
            }
            
        }
        public string ShowMerchantName()
        {
            string output = $"{merchant.Name}";
            return output;
        }
        public string ShowCustomerName()
        {
            string output = $"{customer.Name}";
            return output;
        }
        public void Sell(string name)
        {
            Mode gameMode = Mode.sell;
            bool CanSell = false;
            int itemIndex = 0;
            //foreach (Item i in player.Inventory)
            //{
                
            //    //if (player.Inventory.Contains(i) && craftedProducts.Contains(i))
            //    //{
            //        if (name.ToLower() == i.Name.ToLower())
            //        {
            //            player.RemoveItem(i.Name,i.Amount);
            //            player.Currency = player.Currency + i.Price;
                   

            //        }
            //        else
            //        {
                       
            //        }


            //    //}
            //}
            //Code below was created with the help of tutor karen Spriggs
            for (int i = 0; i < player.Inventory.Count; i++)
            {
                if (player.Inventory[i].Name.ToLower() == name.ToLower())
                {
                    itemIndex = i;
                    CanSell = true;

                }
            }
            if (CanSell)
            {
                player.RemoveItem(player.Inventory[itemIndex].Name, player.Inventory[itemIndex].Amount);
                player.Currency = player.Currency + player.Inventory[itemIndex].Price;
                //MessageBox code was created with the help of Ciarenn Hollis
                MessageBox.Show($" Your profit margin is {player.Inventory[itemIndex].profitValue.ToString("c")}");
                
            }
            else
            {

                MessageBox.Show("You cannot sell that");
            }

        }

       
        public string ShowPlayerCurrency() => $"{player.Currency.ToString("c")}";

    }
}
