﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DynamicBinding
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Tea[] teas = {
            new Tea("Media/greentea.png") {Name = "Oolong", Description = "mild tasting tea", Type = "Green tea" },
            new Tea("Media/greentea.png") {Name = "Jasmine", Description = "bitter tasting tea", Type = "Green tea" },
            new Tea("Media/blacktea.png") {Name = "Assam", Description = "strong earthy tea", Type = "Black tea" },
            new Tea("Media/blacktea.png") {Name = "Earl Grey", Description = "mild earthy tasting tea", Type = "Black tea" },
            new Tea("Media/greentea.png") {Name = "Matcha", Description = "Japanese green tea", Type = "Green tea" },

        };
        int index = 0;
        public MainWindow()
        {
            InitializeComponent();
            SetUp();
        }
        private void SetUp()
        {
            DataContext = teas[index];
            //teas[0].pics = new BitmapImage(new Uri("Media/greentea.png", UriKind.RelativeOrAbsolute));
            //IndexTextblock.Text = $"{teas[index + 1].ToString()}/5";
        }
       
        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            index++;
            if (index >= teas.Length)
            {
                index = 0;
            }
            
            DataContext = teas[index];
            //IndexTextblock.Text = $"{teas[index].ToString()}/5";
        }

        private void DrinkButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"You have chosen the {teas[index].Name} {teas[index].Type}!");
        }
    }
}
