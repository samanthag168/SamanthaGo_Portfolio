﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CardGameFramework.Utility;


namespace CardGameFramework
{
    internal class HighestMatch : Game
    {
        Application application = new Application();
        public override void Startgame(int deckSize, string[] suits)
        {
            base.Startgame(deckSize, suits);
            //Custom code 
            Pause();
            Console.Clear();
            Deal();
            DealerDeal();
            Print("The deck has been shuffled. The dealer has dealt themselves and you a hand of cards. Here is your hand:");
            //roundNumber code and while loop was created with the assistance of Janell Baxter
            int roundNumber = 1;
            while (roundNumber < 10)
            {
                player.ShowCard();
                Print("if you are ready to compare your card to the dealer, press c and enter");
                Print("if you would like to swap out a card for another press, s and enter");
                switch (GetPlayerInput())
                {
                    case "c":
                        Print("The dealer's final hand contains...");
                        dealer.ShowCard();
                        Print("Your final hand:");
                        player.ShowCard();
                        CalculateScore();
                        Pause();
                        EndGame();

                        break;
                    case "s":
                        Print("Which card would you like to swap? Enter a number between 1-4");
                        switch (GetPlayerInput())
                        {
                            case "1":
                                player.Swap(player.Hand[0]);
                                player.DrawCard(deck);
                                Print("Now your hand contains:");
                                player.ShowCard();
                                Pause();
                                break;
                            case "2":
                                player.Swap(player.Hand[1]);
                                player.DrawCard(deck);
                                Print("Now your hand contains:");
                                player.ShowCard();
                                Pause();
                                break;
                            case "3":
                                player.Swap(player.Hand[2]);
                                player.DrawCard(deck);
                                Print("Now your hand contains:");
                                player.ShowCard();
                                Pause();
                                break;
                            case "4":
                                player.Swap(player.Hand[3]);
                                player.DrawCard(deck);
                                Print("Now your hand contains:");
                                player.ShowCard();
                                Pause();
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        break;

                }
                roundNumber++;
                Console.Clear();
                Print($"Round:{roundNumber}");
            }
            //Calculate score code was created with the help of Janell Baxter 
           
            void CalculateScore()
            {
                int[] value = { 0, 0, 0, 0 };
                int[] dealerValue = { 0, 0, 0, 0 };
                foreach (Card c in player.Hand)
                {

                    if (c.Suit == deck.Cards[0].Suit)
                    {
                        value[0] += c.Value;
                        //player.Score = player.Score + 10;
                    }
                    else
                    if (c.Suit == deck.Cards[1].Suit)
                    {
                        value[1] += c.Value;
                        //player.Score = player.Score + 10;
                    }
                    else
                    if (c.Suit == deck.Cards[2].Suit)
                    {
                        value[2] += c.Value;
                        //player.Score = player.Score + 10;
                    }
                    else
                    if (c.Suit == deck.Cards[3].Suit)
                    {
                        value[3] += c.Value;
                        //player.Score = player.Score + 10;
                    }
               
                }
                foreach (Card b in dealer.Hand)
                {
                    if (b.Suit == deck.Cards[0].Suit)
                    {
                        dealerValue[0] += b.Value;
                        //player.Score = player.Score + 10;
                    }
                    else
                    if (b.Suit == deck.Cards[1].Suit)
                    {
                        dealerValue[1] += b.Value;
                        //player.Score = player.Score + 10;
                    }
                    else
                    if (b.Suit == deck.Cards[2].Suit)
                    {
                        dealerValue[2] += b.Value;
                        //player.Score = player.Score + 10;
                    }
                    else
                    if (b.Suit == deck.Cards[3].Suit)
                    {
                        dealerValue[3] += b.Value;
                        //player.Score = player.Score + 10;
                    }
                }
                Array.Sort(value);
                Array.Reverse(value);
                Array.Sort(dealerValue);
                Array.Reverse(dealerValue);
                dealer.Score = dealerValue[0];
                player.Score = value[0];
                Print($"Your score is {player.Score}");
                Print($"The dealer's score is {dealer.Score}");
                if (player.Score < dealer.Score)
                {
                    Print("The dealer has a higher score, you lose!");
                }
                else
                {
                    Print("You have a higher score! You win!");
                }
              
                //foreach (int i in value)
                //{
                //    Print(i.ToString());
                //}
               
            }
        }
        public override void EndGame()
        {
            base.EndGame();
            Console.Clear();
            Console.ResetColor();
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();


            string ASCII = @" 
          _____
         |A .  | _____
         | /.\ ||A ^  | _____
         |(_._)|| / \ ||A _  | _____
         |  |  || \ / || ( ) ||A_ _ |
         |____V||  .  ||(_'_)||( v )|
                |____V||  |  || \ / |
                       |____V||  .  |
                              |____V|
";
            Print(ASCII);
            Print("Welcome to the Card Game Casino!");
            application.Menu();
        }
    }
}
