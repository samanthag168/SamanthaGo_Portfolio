﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGameFramework
{
    internal class Dealer : Player
    {
        Deck deck = new Deck();
        public List<Card> Cards = new List<Card>();
        public List<Card> Hand = new List<Card>();
        public void DrawCard(Deck deck)

        {

            Card card = deck.Cards[0];

            Hand.Add(card);

            deck.Cards.Remove(card);

        }
        public void ShowCard()
        {
            foreach (Card c in Hand)
            {
                Console.WriteLine(c);
            }
        }
        public void Discard()
        {
            Hand.AddRange(Cards);
            Hand.Remove(Card);
        }

    }
}
