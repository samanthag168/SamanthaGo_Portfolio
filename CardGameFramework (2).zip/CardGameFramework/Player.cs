﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace CardGameFramework
{
    internal class Player
    {
        public int Score = 0;
        Deck deck = new Deck(); 
        public List<Card> Cards = new List<Card>();
        public List<Card> Hand = new List<Card>();

        internal Card Card
        {
            get => default;
            set
            {
            }
        }

        public void ShowCard()
        {
            foreach (Card c in Hand)
            { 
            Console.WriteLine(c);
            }
        }

        public void DrawCard(Deck deck)

        {

            Card card = deck.Cards[0];

            Hand.Add(card);

            deck.Cards.Remove(card);

        }
        public void Swap(Card c)
        {
            for (int i = 0; i < Hand.Count; i++)
            {
                if (Hand.Contains(c))
                {
                    Hand.Remove(c);
                    deck.Cards.Add(c);
                }
            }



        }


        public void Discard()
        {
            Hand.Clear();
            
        }
    }
}
