﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using static CardGameFramework.Utility;

namespace CardGameFramework
{
    internal class ApplesToOranges : Game
    {
       //public override void startgame method was created with the help of Janell Baxter
        public override void Startgame(int deckSize, string[] suits)
        {
            base.Startgame(deckSize, suits);
            int roundNumber = 1;
            while (roundNumber < 6)
            {
                player.DrawCard(deck);
                Print("The first drawn card is:");
                player.ShowCard();
                Print("Will the next card be the same suit? type 1 for the same or 2 for different suit");
                player.DrawCard(deck);

                switch (GetPlayerInput())
                {

                    case "1":
                        player.ShowCard();
                        //if the suits are the same the player scores a point
                        //if suits are not the same the player is told 
                        if (CompareSuits(player.Hand[0], player.Hand[1]))
                        {
                            Print("The suits are the same!");
                            player.Score++;
                            Print($"Score:{player.Score}");
                        }
                        else
                        {
                            Console.WriteLine("Your guess is incorrect! nice try");
                            Print($"Score:{player.Score}");
                            //suits are not the same player is told

                        }

                        break;
                    case "2":
                        player.ShowCard();
                        if (CompareSuits(player.Hand[0], player.Hand[1]))
                        {
                            //if suits are the same the player does not get a point
                            Print("Your guess is incorrect! nice try");
                            Print($"Score:{player.Score}");
                        }
                        else
                        {
                            Print("The suits are the same!");
                            player.Score++;
                            Print($"Score:{player.Score}");
                            //if suits are not the same player scores a point
                        }
                        break;
                    default:
                        Print("Please type 1 or 2");
                        break;
                }
                Pause();
                roundNumber++;
                Console.Clear();
                player.Discard();
            }
           // //Custom code below
           // Round1(); 
           //void Round1()
           // {
           //     player.DrawCard(deck);
           //     Print("The first drawn card is:");
           //     player.ShowCard();
           //     Print("Will the next card be the same suit? type 1 for the same or 2 for different suit");
           //     player.DrawCard(deck);

           //     switch (GetPlayerInput())
           //     {
                   
           //         case "1":
           //             player.ShowCard();
           //             //if the suits are the same the player scores a point
           //             //if suits are not the same the player is told 
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 Print("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                 Console.WriteLine("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //                 //suits are not the same player is told

           //             }

           //             break;
           //         case "2":
           //             player.ShowCard();
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 //if suits are the same the player does not get a point
           //                 Print("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                 Print("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //                 //if suits are not the same player scores a point
           //             }
           //             break;
           //         default:
           //             Print("Please type 1 or 2");
           //             break;
           //     }
           //     Pause();
           // }
            
           // Round2(); 
           // void Round2()
           // {
           //     Console.Clear();
           //     player.Discard();
           //     //player.Discard(); clears the players hand so that new cards are drawn each round
           //     player.DrawCard(deck);
           //     Print("The next drawn card is:");
           //     player.ShowCard();
           //     Print("Will the next card be the same suit? type 1 for the same or 2 for different suit");
           //     player.DrawCard(deck);
           //     switch (GetPlayerInput())
           //     {
           //         case "1":
           //             player.ShowCard();
           //             //if the suits are the same the player scores a point
           //             //if suits are not the same the player is told 
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 Console.WriteLine("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                 Console.WriteLine("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //                 //suits are not the same player is told

           //             }

           //             break;
           //         case "2":
           //             player.ShowCard();
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 //if suits are the same the player does not get a point
           //                 Console.WriteLine("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                 Console.WriteLine("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //                 //if suits are not the same player scores a point
           //             }
           //             break;
           //         default:
           //             Console.WriteLine("Please type 1 or 2");
           //             break;
           //     }
           //     Pause();
           // }
           // Round3(); 
           // void Round3()
           // {
           //     Console.Clear();
           //     player.Discard();
           //     //player.Discard(); clears the players hand so that new cards are drawn each round
           //     player.DrawCard(deck);
           //     Print("The next drawn card is:");
           //     player.ShowCard();
           //     Print("Will the next card be the same suit? type 1 for the same or 2 for different suit");
           //     player.DrawCard(deck);
           //     switch (GetPlayerInput())
           //     {
           //         case "1":
           //             player.ShowCard();
           //             //if the suits are the same the player scores a point
           //             //if suits are not the same the player is told 
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 Print("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                Print("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //                 //suits are not the same player is told

           //             }

           //             break;
           //         case "2":
           //             player.ShowCard();
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 //if suits are the same the player does not get a point
           //                 Console.WriteLine("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                 Console.WriteLine("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //                 //if suits are not the same player scores a point
           //             }
           //             break;
           //         default:
           //             Console.WriteLine("Please type 1 or 2");
           //             break;
           //     }
           //     Pause();
           // }
           // Round4();
           // void Round4()
           // {
           //     Console.Clear();
           //     player.Discard();
           //     //player.Discard(); clears the players hand so that new cards are drawn each round
           //     player.DrawCard(deck);
           //     Print("The next drawn card is:");
           //     player.ShowCard();
           //     Print("Will the next card be the same suit? type 1 for the same or 2 for different suit");
           //     player.DrawCard(deck);
           //     switch (GetPlayerInput())
           //     {
           //         case "1":
           //             player.ShowCard();
           //             //if the suits are the same the player scores a point
           //             //if suits are not the same the player is told 
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 Print("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                 Print("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //                 //suits are not the same player is told

           //             }

           //             break;
           //         case "2":
           //             player.ShowCard();
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 //if suits are the same the player does not get a point
           //                 Print("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                 Print("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //                 //if suits are not the same player scores a point
           //             }
           //             break;
           //         default:
           //             Print("Please type 1 or 2");
           //             break;
           //     }
           //     Pause();
           // }
           // Round5();
           // void Round5()
           // {
           //     Console.Clear();
           //     player.Discard();
           //     //player.Discard(); clears the players hand so that new cards are drawn each round
           //     player.DrawCard(deck);
           //     Print("The next drawn card is:");
           //     player.ShowCard();
           //     Print("Will the next card be the same suit? type 1 for the same or 2 for different suit");
           //     player.DrawCard(deck);
           //     switch (GetPlayerInput())
           //     {
           //         case "1":
           //             player.ShowCard();
           //             //if the suits are the same the player scores a point
           //             //if suits are not the same the player is told 
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 Print("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                Print("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //                 //suits are not the same player is told

           //             }

           //             break;
           //         case "2":
           //             player.ShowCard();
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 //if suits are the same the player does not get a point
           //                 Print("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                 Print("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //                 //if suits are not the same player scores a point
           //             }
           //             break;
           //         default:
           //             Print("Please type 1 or 2");
           //             break;
           //     }
           //     Pause();
           // }
           // Round6();
           // void Round6()
           // {
           //     Console.Clear();
           //     player.Discard();
           //     //player.Discard(); clears the players hand so that new cards are drawn each round
           //     player.DrawCard(deck);
           //     Print("The next drawn card is:");
           //     player.ShowCard();
           //     Print("Will the next card be the same suit? type 1 for the same or 2 for different suit");
           //     player.DrawCard(deck);
           //     switch (GetPlayerInput())
           //     {
           //         case "1":
           //             player.ShowCard();
           //             //if the suits are the same the player scores a point
           //             //if suits are not the same the player is told 
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 Print("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                 Print("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //                 //suits are not the same player is told

           //             }

           //             break;
           //         case "2":
           //             player.ShowCard();
           //             if (CompareSuits(player.Hand[0], player.Hand[1]))
           //             {
           //                 //if suits are the same the player does not get a point
           //                 Print("Your guess is incorrect! nice try");
           //                 Print($"Score:{player.Score}");
           //             }
           //             else
           //             {
           //                 Print("The suits are the same!");
           //                 player.Score++;
           //                 Print($"Score:{player.Score}");
           //                 //if suits are not the same player scores a point
           //             }
           //             break;
           //         default:
           //             Console.WriteLine("Please type 1 or 2");
           //             break;
           //     }
               
           // }
            EndGame();
        }
        public override void EndGame()
        {
            base.EndGame();
        }
    }
}
