﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGameFramework
{
    public struct Card
    {
        public int Value = 1;
        public Card(string rank, string suit, int value) : this()
        {

            Rank = rank;
            Suit = suit;
            Value = value;
        }

        public string Rank { get; }
        public string Suit { get; }

        public override string ToString() => $"{Rank} of {Suit}";



    }
}
