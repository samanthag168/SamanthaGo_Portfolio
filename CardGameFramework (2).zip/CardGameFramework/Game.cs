﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CardGameFramework.Utility;
using static System.Console;


namespace CardGameFramework
{
      class Game
    {
        public Dealer dealer = new Dealer();
        public Player player = new Player();
        public string name; 
        public Deck deck = new Deck();
        //public List<Card> Cards = new List<Card>();
        public string Instructions; 
     
        
        
        public void ShowInstructions()
        {
            Print(Instructions);
        }
        public void Deal()
        {
            player.DrawCard(deck);
            player.DrawCard(deck);
            player.DrawCard(deck);
            player.DrawCard(deck);
        }
        public void DealerDeal()
        {
            dealer.DrawCard(deck);
            dealer.DrawCard(deck);
            dealer.DrawCard(deck);
            dealer.DrawCard(deck);
        }
        //start game method created with the help of Janell Baxter
        public virtual void Startgame(int deckSize, string[] suits)
        {
            Print($"Welcome to {name}");
           ShowInstructions(); 
            deck.CreateDeck(deckSize, suits);
            deck.Shuffle();
        }

        public virtual void EndGame()
        {
            Print($"Thank you for playing {name}! Your score is:{player.Score}");
           
        }
    }
}
