﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGameFramework
{
    internal class Utility
    {
        public static void Print(string Message)
        { 
        Console.WriteLine(Message);
        }
        public static string GetPlayerInput() => Console.ReadLine();
        public static void Pause()
        {
            Print("Press any key to continue");
            Console.ReadKey();
        
        }
        public static bool CompareSuits(Card c, Card b)
        {
            if (c.Suit == b.Suit)
            {
                return true;
            }
            return false; 
        }
        public static bool CompareRank(Card c, Card b)
        {
            if (c.Rank[0] > b.Rank[0])
            {
                return true;
            }
            if (c.Rank[0] == b.Rank[0] && c.Suit != b.Suit)
            {
                return false;
            }
            return false; 
        }
        

    }
}
