﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CardGameFramework.Utility;
using static System.Console;

namespace CardGameFramework
{
    internal class Application
    {
        Game game; 
        public void LoadGame()
        {
            Console.Clear();
            Console.ResetColor();
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
           
           
            string ASCII = @" 
          _____
         |A .  | _____
         | /.\ ||A ^  | _____
         |(_._)|| / \ ||A _  | _____
         |  |  || \ / || ( ) ||A_ _ |
         |____V||  .  ||(_'_)||( v )|
                |____V||  |  || \ / |
                       |____V||  .  |
                              |____V|
";
            Print(ASCII);
            Print("Welcome to the Card Game Casino!");

            Menu();
        }
        public void Menu()
        {
            //game.Startgame() codes are created with the help of Janell Baxter

            //Console.Clear();
            Print("Please select an option by typing a number: \n 1. Apples or Oranges\n 2. Higher or Lower\n 3. Highest Match\n 4. Credits");
            switch (GetPlayerInput())
            {
                case "1":
                    game = new ApplesToOranges() { name = "Apples or Oranges", Instructions = "A card is drawn from a shuffled deck and shown to the player. The player then guesses what the suit of the next card will be - will it be the same or different? For each correct guess, the player gains a point." };
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.Clear();
                    game.Startgame(26,new string[] { "Apples","Oranges"});

                    break;

                    case "2":
                    game = new HigherorLower() {name = "Higher or Lower", Instructions = "A card is drawn from a shuffled deck and shown to the player. The player then guesses whether the next card drawn will have a higher or lower value. For each correct guess, the player gains a point. If the value of the card is the same (but a different suit) the player doesn't receive a point." };
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkMagenta;
                    Console.Clear();
                    game.Startgame(52, new string[] {"Spades", "Clovers", "Diamonds", "Hearts" });
                    break;

                case "3":
                    game = new HighestMatch() { name = "Highest Match", Instructions = "The player has 10 rounds to collect cards that have the same suit and the highest values. They can discard one card per turn, and gain one card per turn.At the end of 10 rounds, the game will look at the player's cards. If the player has a set of the same suit that in total has a higher value than the dealer's, they win." };
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    game.Startgame(52, new string[] { "Spades", "Clovers", "Diamonds", "Hearts" });
                    break;
                case "4":
                    ShowCredits();
                    break;
                default:
                    Print("Please type a valid number/choice");
                    break;
                    
            }
            Pause();
            LoadGame();
        }
        public void ShowCredits()
        {
            Print("Created by Samantha Go for Programming II, code credit from Jannell Baxter and Rosetta Code. ASCII art is from https://www.asciiart.eu/.");
        }
    }
}
