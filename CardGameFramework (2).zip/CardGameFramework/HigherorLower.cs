﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CardGameFramework.Utility;

namespace CardGameFramework
{
    internal class HigherorLower : Game
    {
        public override void Startgame(int deckSize, string[] suits)
        {
            base.Startgame(deckSize, suits);
            int roundNumber = 1;
            //custom code
            while (roundNumber < 6)
            {
                
                player.DrawCard(deck);
                Print("The first drawn card is:");
                player.ShowCard();
                Print("Will the next card be higher or lower? type 1 for higher, 2 for lower");
                player.DrawCard(deck);
                switch (GetPlayerInput())
                {
                    case "1":
                        player.ShowCard();
                        if (CompareRank(player.Hand[0], player.Hand[1]))
                        {
                            Print("You guessed correct! You gain a point");
                            player.Score++;
                            Print($"{player.Score}");
                        }
                        else
                        {
                            Print("The value is either lower or equal but the suits are different :( You did not gain a point");
                            Print($"{player.Score}");
                        }
                        break;
                    case "2":
                        player.ShowCard();
                        if (CompareRank(player.Hand[0], player.Hand[1]))
                        {
                            Print("The value is either higher or equal but the suits are different :( You did not gain a point");
                            Print($"{player.Score}");
                        }
                        else
                        {
                            Print("You guessed correct! You gain a point");
                            player.Score++;
                            Print($"{player.Score}");
                        }
                        break;
                    default:
                        Print("Please type 1 or 2");
                        GetPlayerInput();
                        break;
                }
                Pause();
                roundNumber++;
                Console.Clear();
                player.Discard();
            }
           
            EndGame();
        }
        public override void EndGame()
        {
            base.EndGame();
        }
    }
}
