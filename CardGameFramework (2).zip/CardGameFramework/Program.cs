﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CardGameFramework.Utility;

namespace CardGameFramework
{
    /*
 * Card Game Framework
 * Samantha Go, 10/16/22
 * Credits
 * - Random number and shuffling code from PROG 201 class demo
 * - Functionality for the game apples or oranges and highest match was created with help from Janell Baxter
 * - the creation of the card struct code was from the struct assignment in class which is from the website rosetta code
 * -ASCII art is from https://www.asciiart.eu/ 
 * - additional help with coding the ASCII art and console app colors is from the website http://programmingisfun.com/ 
 */
    public class Program
    {
       
        public static void Main()
        {
            Application application = new Application();
            application.LoadGame();
            //application.Menu();
            // Deck.CalculateValues();

        }

    }
}
