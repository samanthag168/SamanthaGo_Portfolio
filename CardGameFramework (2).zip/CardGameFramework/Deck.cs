﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGameFramework
{
     class Deck
    {
        
        public int suits;
       
        public List<Card> Cards = new List<Card>();
        static string[] Suits = { "Spades","Clovers","Diamonds","Hearts"};
        public string[] Rank = { "Ace","2","3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };
      
        public int deckSize;
       
        Random random = new Random();
        public void CreateDeck(int deckSize, string[] suits)
        {
          
            //Cards = (from suit in suits
            //         from rank in Rank
            //         select new Card(rank, suit,cardValue++)).ToList();
            for (int i=0; i<Suits.Length; i++)
            {
                for (int j=0; j<Rank.Length; j++)
                {
                    Cards.Add(new Card(Rank[j], Suits[i], j + 1));
                }
            }
        }
        public int Count => Cards.Count;
        public void Shuffle()
        {
            //Credit to Rosetta Code 
            var random = new Random();
            for (int i = 0; i < Cards.Count; i++)
            {
                int r = random.Next(i, Cards.Count);
                var temp = Cards[i];
                Cards[i] = Cards[r];
                Cards[r] = temp;
            }
        }
        //public static void CalculateValues()
        //{
        //    for (int i = 1; i <= deckSize / Suits.Length; i++)
        //    {
        //        for (int j = 0; j < Suits.Length; j++)
        //        {
        //            Cards.Add(new Card()
        //            {
        //                Value = i,
        //                Suit = Suits[j]
        //            }
                    
        //        );
        //            if (i == 11)
        //            {
        //                Console.WriteLine($"{FaceCards[0]} of {Suits[j]}");
        //            }
        //            if (i == 12)
        //            {
        //                Console.WriteLine($"{FaceCards[1]} of {Suits[j]}");
        //            }
        //            if (i == 13)
        //            {
        //                Console.WriteLine($"{FaceCards[2]} of {Suits[j]}");
        //            }
        //            else
        //            {
        //                Console.WriteLine($"{i} of {Suits[j]}");
        //            }
                    
                    
        //        }



        //    }
            

        //}

       
    }
}
